## Known bugs
- Handle 類無法處理非同步函式