'''
Some useful metaclass.
'''
__all__ = ['PathMeta']

from ._meta import PathMeta