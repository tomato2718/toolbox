'''
Not for import, import LogTool instead.
'''

from ._logging import LogTool